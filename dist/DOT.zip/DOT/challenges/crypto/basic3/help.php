<?php 
   include '../../../global/dotGlobal_config.inc.php';
?>
<body class="dot_dashboard app-darkmode" id="dot_dashboard">
  <div class="dot_mb_2">
    <h2 class="body_title_sub dot_white font_monts has_icon dot_mb_1">Seriously?</h2>
    <h3 class="font_mono dot_no_white dot_f14 l_h_1_4">-_-</h3>
  </div>
  <div class="">
    <h2 class="body_title_sub dot_white font_monts has_icon dot_mb_1">-</h2>
    <h3 class="font_mono dot_no_white dot_f14 l_h_1_4 dot_mb_2">-</h3>
    <h3 class="font_mono dot_no_white dot_f14 l_h_1_4 dot_mb_1">
      <?php 
          for($i=0;$i<2000;$i++){
            echo "I DID IT WANTEDLY<br>";
          }
      ?>
    </h3>
    </div>
</body>