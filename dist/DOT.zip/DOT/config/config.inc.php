<?php

# This file will be overriden
# 	!!DO NOT EDIT!!
#
# DOT Web App Database config file. 
# if you are using xampp/wampp make sure to set the db_server to 'localhost' to avoid any errors
#
# Database variables
#   Please do not edit the config file unless required. Default database name is set to dot in the setup form.

$DOT_DBHOST='/';
$DOT_DBUSER='/';
$DOT_DBPASS='/';
$DOT_DBNAME='/';



?>